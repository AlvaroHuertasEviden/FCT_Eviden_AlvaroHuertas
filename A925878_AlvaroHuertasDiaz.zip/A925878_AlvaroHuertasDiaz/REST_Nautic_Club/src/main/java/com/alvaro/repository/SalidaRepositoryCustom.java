package com.alvaro.repository;

public interface SalidaRepositoryCustom {
	long countSalidasByBarcoAndCapitanNoSocio(String matricula);
}
