package com.alvaro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestNauticClubApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestNauticClubApplication.class, args);
    }

}
