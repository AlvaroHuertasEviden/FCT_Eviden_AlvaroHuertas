import { Component, Input, OnInit } from '@angular/core';
import { Socio } from '../../models/socio.model';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { SocioService } from '../../services/socio.service';

/**
 * Componente que muestra un modal para editar o borrar un socio.
 */
@Component({
  selector: 'app-edit-socio-modal',
  standalone: true,
  imports: [
    ReactiveFormsModule
  ],
  templateUrl: './edit-socio-modal.component.html',
  styleUrl: './edit-socio-modal.component.css',
  providers: [
    SocioService
  ]
})
export class EditSocioModalComponent implements OnInit {
  @Input()
  socio!: Socio;

  socioEditForm!: FormGroup;

  constructor(private socioService: SocioService, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.socioEditForm = this.formBuilder.group({
      nombre: [this.socio.nombre],
      telefono: [this.socio.telefono],
      cuota: [this.socio.cuota]
    });
  }

  onSubmit() {
    this.socioService.updateSocio(this.socio.id, this.socioEditForm.value).subscribe((data) => {
      this.socio = data;
    });

    var boton = document.getElementById("closeModal");
    if (boton) {
      boton.click();
    }
  }

  onDelete()  {
    console.log(`Deleting socio with id ${this.socio.id}`);
    this.socioService.deleteSocio(this.socio.id).subscribe((data) => {
      console.log(`Socio with id ${this.socio.id} deleted`);
    });
    var boton = document.getElementById("closeModal");
    if (boton) {
      boton.click();
    }
  }
  
}
