import { Component, OnInit } from '@angular/core';

import { AuthService } from '../../services/auth.service';
import { StorageService } from '../../services/storage.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

/**
 * Componente que muestra la página de login.
*/
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule
  ]
})
export class LoginComponent implements OnInit {

  form: any = {
    username: null,
    password: null
  };

  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roles: string[] = [];

  constructor(private authService: AuthService, private storageService: StorageService, private router: Router) { }

  ngOnInit(): void {
    if (this.storageService.isLoggedIn()) {
      this.isLoggedIn = true;
      this.roles = this.storageService.getUser().roles;
      setTimeout(() => {
        this.router.navigate(['/']);
      }, 1000);
    }
  }

  onSubmit(): void {
    const { username, password } = this.form;

    

    this.authService.login(username, password).subscribe({
      next: data => {
        this.storageService.saveUser(data);

        

        this.isLoginFailed = false;
        this.isLoggedIn = true;
        this.roles = this.storageService.getUser().roles;
        this.reloadPage();
      },
      error: err => {
        this.errorMessage = err.error.message;
        this.isLoginFailed = true;
      }
    });
  }

  reloadPage(): void {
    window.location.reload();
  }

  logout() {
    this.authService.logout().subscribe(
      data => {
        console.log(data);
      },
      err => {
        console.log(err);
      }
    );
    this.isLoggedIn = false;
    this.form = {
      username: null,
      password: null
    };
    this.storageService.logout();
    this.reloadPage();
  }
}