import { Component, OnInit, TemplateRef } from '@angular/core';
import { Socio } from '../../models/socio.model';
import { Router, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { SocioService } from '../../services/socio.service';

import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { EditSocioModalComponent } from '../edit-socio-modal/edit-socio-modal.component';

/*
* Componente que muestra la tabla de socios.
*/
@Component({
  selector: 'app-socio',
  standalone: true,
  imports: [
    RouterModule,
    ReactiveFormsModule,
    EditSocioModalComponent
  ],
  templateUrl: './socio.component.html',
  styleUrl: './socio.component.css',
  providers: [SocioService, BsModalService]
})
export class SocioComponent implements OnInit {

  socios: Socio[] = [];
  socio!: Socio;
  socioForm!: FormGroup;
  modalRef?: BsModalRef;
  loading: boolean = true;

  constructor(
    private socioService: SocioService, 
    private formBuilder: FormBuilder,
    private modalService: BsModalService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.socioService.getSocios().subscribe((data) => {
      this.socios = data;
    },
    (error) => {
      console.error(error);
      if (error.status === 401) {
        this.router.navigate(['/login']).then(() => {
          alert('No autorizado, inicie sesión primero');
        });
      }
    });

    this.socioForm = this.formBuilder.group({
      nombre: [''],
      telefono: [],
      cuota: []
    });

    this.loading = false;
  }

  onSubmit() {
    this.socioService.createSocio(this.socioForm.value).subscribe((data) => {
      this.socios.push(data);
      this.socioForm.reset();
    });
  }

  // Función JavaScript para mostrar el formulario

  mostrarFormulario() {
      var formulario = document.getElementById("formularioCliente");
      var boton = document.getElementById("botonFormulario");
      var tabla = document.querySelector(".scrollable-table") as HTMLTableElement | null;
      if (formulario?.style.display === "none") {
          formulario.style.display = "block";
          boton!.textContent = "Cancelar";
          boton!.classList.remove("btn-primary");
          boton!.classList.add("btn-danger");
          tabla!.style.maxHeight = "350px";
      } else {
          formulario!.style.display = "none";
          boton!.textContent = "Agregar cliente";
          boton!.classList.remove("btn-danger");
          boton!.classList.add("btn-primary");
          tabla!.style.maxHeight = "400px";
      }
  }

  openModal(template: TemplateRef<any>, socio: Socio) {
    this.socio = socio;
    this.modalRef = this.modalService.show(template, { initialState: { socio } });
  }

  exitModal() {
    this.modalRef?.hide();
    this.loading = true;
    setTimeout(() => {
      this.ngOnInit();
    }, 500);
  }
}
