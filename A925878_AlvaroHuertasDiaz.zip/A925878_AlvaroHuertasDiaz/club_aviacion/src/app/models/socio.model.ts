/* Modelo Socio */
export class Socio {
    id: number;
    nombre: string;
    telefono: string;
    cuota: number;
    barcos: any[];
    salidas: number;
  
    constructor(id: number, nombre: string, telefono: string, cuota: number, barcos: any[], salidas: number) {
      this.id = id;
      this.nombre = nombre;
      this.telefono = telefono;
      this.cuota = cuota;
      this.barcos = barcos;
      this.salidas = salidas;
    }
  }