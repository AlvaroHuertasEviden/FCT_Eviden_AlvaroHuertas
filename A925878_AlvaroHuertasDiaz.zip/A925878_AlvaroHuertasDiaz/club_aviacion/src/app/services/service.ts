const apiUrl: String = 'http://localhost:8080';

export { apiUrl };