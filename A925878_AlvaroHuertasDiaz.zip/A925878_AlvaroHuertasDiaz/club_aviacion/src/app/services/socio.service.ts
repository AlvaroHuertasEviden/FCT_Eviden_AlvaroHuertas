import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Socio } from '../models/socio.model';
import { Observable } from 'rxjs';
import { apiUrl } from './service';


const apiUrlSocios = `${apiUrl}/socios`;

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

/*
* Servicio que gestiona los socios.
*/
@Injectable({
  providedIn: 'root'
})
export class SocioService {

  

  constructor(private http: HttpClient) { }

  getSocios(): Observable<any> {
    return this.http.get<Socio[]>(apiUrlSocios);
  }

  createSocio(socio: Socio): Observable<Socio> {
    return this.http.post<Socio>(apiUrlSocios, socio);
  }

  updateSocio(id: number, socio: Socio): Observable<Socio> {
    return this.http.put<Socio>(`${apiUrlSocios}/${id}`, socio);
  }

  deleteSocio(id: number) {
    return this.http.delete(`${apiUrlSocios}/${id}`);
  }
}
