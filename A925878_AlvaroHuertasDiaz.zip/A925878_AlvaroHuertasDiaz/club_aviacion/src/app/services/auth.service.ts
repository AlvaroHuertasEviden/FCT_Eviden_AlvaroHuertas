import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { apiUrl } from './service';
import { StorageService } from './storage.service';

const AUTH_API = `${apiUrl}/api/auth/`;

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

interface LoginResponse {
  jwt: string;
}

/**
 * Servicio que gestiona la autenticación de los usuarios.
 */
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private http: HttpClient, private storageService: StorageService) {}

  login(username: string, password: string): Observable<any> {
    return this.http.post<LoginResponse>(
      AUTH_API + 'signin',
      {
        username,
        password,
      },
      { withCredentials: true }
    ).pipe(tap(response => {
      console.log(response);
      let jwt = response.jwt;
      this.storageService.saveToken(jwt);
    }));
  }

  register(username: string, email: string, password: string): Observable<any> {
    const role: string[] = ['ROLE_USER', 'ROLE_ADMIN', 'ROLE_MODERATOR'];
    return this.http.post(
      AUTH_API + 'signup',
      {
        username,
        email,
        role,
        password,
      },
      httpOptions
    );
  }

  logout(): Observable<any> {
    return this.http.post(AUTH_API + 'signout', { }, httpOptions);
  }
}